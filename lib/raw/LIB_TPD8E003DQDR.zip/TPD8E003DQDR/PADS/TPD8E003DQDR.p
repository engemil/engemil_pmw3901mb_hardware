*PADS-LIBRARY-PART-TYPES-V9*

TPD8E003DQDR SON40P135X170X80-9N I ANA 7 1 0 0 0
TIMESTAMP 2025.06.13.10.27.10
"Mouser Part Number" 595-TPD8E003DQDR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/TPD8E003DQDR?qs=hEBn5lgDlCo1%252BvgoUxxo%252Bg%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TPD8E003DQDR
"Description" 8-Channel ESD Array For Portable Space-Saving Applications
"Datasheet Link" http://www.ti.com/lit/gpn/tpd8e003
"Geometry.Height" 0.8mm
GATE 1 9 0
TPD8E003DQDR
1 0 U IO1
2 0 U IO2
3 0 U IO3
4 0 U IO4
9 0 U EP/GND
8 0 U IO8
7 0 U IO7
6 0 U IO6
5 0 U IO5

*END*
*REMARK* SamacSys ECAD Model
752298/1471904/2.50/9/3/Integrated Circuit
