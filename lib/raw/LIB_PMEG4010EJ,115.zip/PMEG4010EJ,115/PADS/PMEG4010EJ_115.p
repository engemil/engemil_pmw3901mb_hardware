*PADS-LIBRARY-PART-TYPES-V9*

PMEG4010EJ_115 SODFL2512X80N I DIO 7 1 0 0 0
TIMESTAMP 2025.06.13.09.48.42
"Mouser Part Number" 771-PMEG4010EJ-T/R
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Nexperia/PMEG4010EJ115?qs=LOCUfHb8d9vkFKX8Dwc9CA%3D%3D
"Manufacturer_Name" Nexperia
"Manufacturer_Part_Number" PMEG4010EJ,115
"Description" NEXPERIA - PMEG4010EJ,115 - Schottky Rectifier, 40 V, 1 A, Single, SOD-323F, 2 Pins, 640 mV
"Datasheet Link" https://ad.componentsearchengine.com/Datasheets/2/PMEG4010EJ,115.pdf
"Geometry.Height" 0.8mm
GATE 1 2 0
PMEG4010EJ_115
1 0 U K
2 0 U A

*END*
*REMARK* SamacSys ECAD Model
833523/1471904/2.50/2/2/Schottky Diode
