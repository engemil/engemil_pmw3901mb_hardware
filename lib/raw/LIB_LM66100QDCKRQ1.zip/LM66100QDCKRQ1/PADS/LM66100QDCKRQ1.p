*PADS-LIBRARY-PART-TYPES-V9*

LM66100QDCKRQ1 SOT65P210X110-6N I ANA 7 1 0 0 0
TIMESTAMP 2025.06.24.10.29.26
"Mouser Part Number" 595-LM66100QDCKRQ1
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/LM66100QDCKRQ1?qs=MyNHzdoqoQIvjdvtKQd0jA%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" LM66100QDCKRQ1
"Description" Power Management Specialized - PMIC Automotive 1.5-V to 5.5-V, 1.5-A, 0.5-uA IQ ideal diode with integrated FET
"Datasheet Link" https://www.ti.com/lit/ds/symlink/lm66100-q1.pdf?ts=1647247642374&ref_url=www.ti.com
"Geometry.Height" 1.1mm
GATE 1 6 0
LM66100QDCKRQ1
1 0 U VIN
2 0 U GND
3 0 U \CE
6 0 U VOUT
5 0 U ST
4 0 U N/C

*END*
*REMARK* SamacSys ECAD Model
16187619/1471904/2.50/6/3/Integrated Circuit
