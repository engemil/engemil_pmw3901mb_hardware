*PADS-LIBRARY-PART-TYPES-V9*

RC0805FR-100RL RESC2012X60N I RES 7 1 0 0 0
TIMESTAMP 2025.06.13.09.28.14
"Mouser Part Number" 603-RC0805FR-100RL
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/YAGEO/RC0805FR-100RL?qs=g6xwsc4j%252B%2FqfSt9luyhNYQ%3D%3D
"Manufacturer_Name" YAGEO
"Manufacturer_Part_Number" RC0805FR-100RL
"Description" Thick Film Resistors - SMD 0 Ohms 125 mW 0805 1%
"Datasheet Link" https://www.mouser.in/datasheet/2/447/PYu_RC_Group_51_RoHS_L_11-1984063.pdf
"Geometry.Height" 0.6mm
GATE 1 2 0
RC0805FR-100RL
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
17310716/1471904/2.50/2/3/Resistor
